const doctors = [
  { id: '1', firstName: 'Christy', lastName: 'Schumm' },
  { id: '2', firstName: 'Natalia', lastName: 'Stanton Jr.' },
  { id: '3', firstName: 'Nola', lastName: 'Murazik V' },
  { id: '4', firstName: 'Elyssa', lastName: `O'Kon` },
  { id: '5', firstName: 'Dr. Geovany', lastName: `Keebler` },
]

export default doctors
